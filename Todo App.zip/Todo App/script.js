const input = document.querySelector('input');
const ul = document.querySelector('ul');
const form = document.querySelector('form');
const clear = document.querySelector('.btn');
const count = document.querySelector('.count');
const plus = document.querySelector('img');

form.onsubmit = (e) => {
    e.preventDefault();
    if (!input.value) {
        return;
    }

    // const listItems = ul.getElementsByTagName('li');
    const li = document.createElement('li');
    const bin = document.createElement('img');
    bin.src = "picture/trash-can-black-symbol.png";
    bin.alt = "Delete";
    bin.classList.add('delete');
    li.classList.add('listyle')

    li.textContent = input.value;
    li.appendChild(bin); 
    ul.appendChild(li);
    count.textContent = ul.getElementsByTagName('li').length;    // count list items
    input.value = "";

 //                   click on bin
    bin.onclick = (e) => {
        e.stopPropagation(); 
        li.remove();
        count.textContent = ul.getElementsByTagName('li').length;
    };
    li.onclick = () => {
        if (li.classList.contains('crossed-out')) {
            li.classList.remove('crossed-out');
            count.textContent = ul.getElementsByTagName('li').length;
        } else {
            li.classList.add('crossed-out');
            count.textContent = ul.getElementsByTagName('li').length - 1;
        }
    };

};
//                      button clear all
clear.onclick = (e) => {
    e.preventDefault();
    if (confirm("Do you want to clear all Todo?")) {
        
        const listItems = ul.getElementsByTagName('li');
        while (listItems.length > 0) {
            listItems[0].remove();
        }

        count.textContent = ul.getElementsByTagName('li').length;
    }
    //                   count list items
    
};




// Buy a new gaming laptop
// Completet a previous task
// Create video for youtube
// Create a new paartfolio site