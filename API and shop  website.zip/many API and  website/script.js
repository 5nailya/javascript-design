const apiUrls = [
  "https://mocki.io/v1/265adb61-6059-4e3c-9be6-0b406732a467", // Rings
  "https://mocki.io/v1/bee692d8-c995-4404-9d7d-830f5eb0fc66", // Bracelets
  "https://mocki.io/v1/e0d14087-8e86-41b0-8246-b3b59f2b2a44", // Necklaces
  "https://mocki.io/v1/d6388689-9011-4000-b79d-f59704bab726"  // Other Accessories
];

// Fetch and display products
async function fetchAndDisplayProducts() {
  try {
      const responses = await Promise.all(apiUrls.map(url => fetch(url)));
      const data = await Promise.all(responses.map(res => res.json()));
      const products = data.flatMap(item => item);

      renderProducts(products);
      updateMatchingCount(products.length);

      document.getElementById('apply-filter').addEventListener('click', () => filterProducts(products));
      document.querySelectorAll('.dropdown-item').forEach(item => {
          item.addEventListener('click', () => filterByCategory(products, item));
      });
  } catch (error) {
      console.error('Error fetching products:', error);
  }
}

// Update matching product count
function updateMatchingCount(count) {
  const countElement = document.getElementById('matching-count');
  countElement.textContent = `${count} product${count !== 1 ? 's' : ''} found`;
}

// Filter products by category
function filterByCategory(products, categoryItem) {
  const category = categoryItem.getAttribute('data-category');
  const filteredProducts = products.filter(product => product.category === category);
  renderProducts(filteredProducts);
  updateMatchingCount(filteredProducts.length);
}

// Filter products
function filterProducts(products) {
  const searchTitle = document.getElementById('search-title').value.toLowerCase();
  const minPrice = parseFloat(document.getElementById('min-price').value) || 0;
  const maxPrice = parseFloat(document.getElementById('max-price').value) || Infinity;
  const category = document.getElementById('category-select').value;

  const filteredProducts = products.filter(product => {
      const matchesTitle = product.name.toLowerCase().includes(searchTitle);
      const matchesPrice = product.price >= minPrice && product.price <= maxPrice;
      const matchesCategory = !category || product.category === category;

      return matchesTitle && matchesPrice && matchesCategory;
  });

  renderProducts(filteredProducts);
  updateMatchingCount(filteredProducts.length);
}

// Render products
function renderProducts(products) {
  const productContainer = document.getElementById('product-cards');
  productContainer.innerHTML = products
      .map(product => `
      <div class="card">
          <img src="${product.image}" class="card-img-top mt-3" alt="${product.name}">
          <div class="card-body">
              <h5 class="card-title">${product.name}</h5>
              <p class="card-text">${product.description}</p>
              <p class="card-text text-primary"><strong>$${product.price}</strong></p>
              <p class="card-text">Rating: ⭐${product.rating}</p>
          </div>
      </div>
      `)
      .join('');

  const cards = document.querySelectorAll('#product-cards .card');
  cards.forEach((card, index) => {
      card.style.animation = 'fadeIn 1s ease forwards';
      card.style.animationDelay = `${index * 0.2}s`;
  });
}

// Toggle theme
document.getElementById('theme-toggle').addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
});

fetchAndDisplayProducts();

document.addEventListener('DOMContentLoaded', () => {
  const cards = document.querySelectorAll('#product-cards .card');
  cards.forEach((card, index) => {
      card.style.animationDelay = `${index * 0.2}s`;
  });
});
