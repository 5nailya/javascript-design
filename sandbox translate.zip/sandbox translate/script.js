let navLink = document.querySelectorAll('.nav-link'); //+
let langBtn = document.querySelector('#lang-btn'); //+
let paragraphh = document.getElementsByClassName('paragraph'); //+
// let ech1 = document.getElementsByTagName('h1');
let ctitle = document.getElementsByClassName('card-title'); //+
// let ctext = document.getElementsByClassName('card-text');
let ech5 = document.getElementsByClassName('gr'); //+
let ech2 = document.getElementsByClassName('hh2'); //+
let button = document.getElementsByClassName('btn'); //+
let footer = document.getElementsByClassName('foot'); // Fix: Typo removed and correct variable name //+

let currentLang = "en"; // Default language is English

const data = {
    en: {
        lang: ["Home", "Pages", "Projects", "Blog", "Blocks", "Documentation"],

        ctitle: ["We bring solutions to make life easier", "Content Marketing", "Social Engagement", "Card 3", "Product Design", "Collect Ideas", "Data Analysis", "Finalize Product", "Finalize Product"],

        paragraphh: ["We are a creative company that focuses on long term relationships with customers.", "Why Choose Sandbox?", "Save Time and Money", "Financial Analyst", "Marketing Specialist", "Sales Manager", "WHAT MAKES US DIFFERENT?", "JOIN OUR COMMUNITY"],

        ech2: ["Here are a few reasons why our customers choose Sandbox.", "Save your time and money by choosing our professional team.", "We are trusted by over 5000+ clients. Join them now and grow your business."],

        ech5: ["We bring solutions to make life easier for our customers.", "Creativity", "Innovative Thinking", "Rapid Solutions", "Top-Notch Support"],

        footer: ["© 2024 MyWebsite", "All Rights Reserved", "Get in Touch", "Moonshine St. 14/05", "London", "United Kingdom", "info@email.com", "00 (123) 456 78 90", "Learn More", "About Us", "Our Story", "Projects", "Terms of Use", "Privacy Policy", "Our Newsletter", "Subscribe to our newsletter to get our news & deals delivered to you."],
        
        button: ["read more", "Learn More", "Learn More", "Learn More", "Learn More", "Learn More", "Get started", "Previous", "Next", "Get Started", "Join"]
    },
    ru: {
        lang: ["Главная", "Страницы", "Проекты", "Блог", "Блоки", "Документация"],
        
        ctitle: ["Мы предлагаем решения, которые облегчают жизнь", "Контент-маркетинг", "Социальное взаимодействие", "Карточка 3", "Дизайн продукта", "Собирайте идеи", "Анализ данных", "Завершить продукт", "Завершить продукт"],
        
        paragraphh: ["Мы креативная компания, которая фокусируется на долгосрочных отношениях с клиентами.", "Почему выбирают Sandbox?", "Экономьте время и деньги", "Финансовый аналитик", "Специалист по маркетингу", "Менеджер по продажам", "ЧЕМ МЫ ОТЛИЧАЕМСЯ?", "ПРИСОЕДИНЯЙТЕСЬ К НАШЕМУ СООБЩЕСТВУ"],
        
        ech2: ["Вот некоторые из причин, по которым наши клиенты выбирают Sandbox.", "Экономьте свое время и деньги, выбрав нашу профессиональную команду.", "Нам доверяют более 5000+ клиентов. Присоединяйтесь к ним сейчас и развивайте свой бизнес."],
        
        ech5: ["Мы предоставляем решения, которые облегчают жизнь нашим клиентам", "Творчество", "Инновационное мышление", "Быстрые решения", "Первоклассная поддержка"],
        
        footer: ["© 2024 MyWebsite", "Все права защищены", "Свяжитесь с нами", "Moonshine St. 14/05", "Лондон", "Великобритания", "info@email.com", "00 (123) 456 78 90", "Узнать больше", "О нас", "Наша история", "Проекты", "Условия использования", "Политика конфиденциальности", "Наша рассылка", "Подпишитесь на нашу рассылку, чтобы получать наши новости и предложения."],
        
        button: ["читать дальше", "Узнать больше", "Узнать больше", "Узнать больше", "Узнать больше", "Узнать больше", "Начать", "Предыдущая", "Следующая", "Начать", "Присоединиться"],
    },
}

const changeLang = (e) => {
    e.preventDefault(); // Refresh olunmasin

    currentLang = currentLang === "en" ? "ru" : "en"; // en olsa ru, ru olsa en olsun

    data[currentLang].lang.forEach((item, index) => {
        if (navLink[index]) {
            navLink[index].innerHTML = item; 
        }
    });

    data[currentLang].ctitle.forEach((item, index) => {
        if (ctitle[index]) {
            ctitle[index].innerHTML = item; 
        }
    });


    data[currentLang].paragraphh.forEach((item, index) => {
        if (paragraphh[index]) {
            paragraphh[index].innerHTML = item; 
        }
    });

    data[currentLang].ech2.forEach((item, index) => {
        if (ech2[index]) {
            ech2[index].innerHTML = item; 
        }
    });


    data[currentLang].ech5.forEach((item, index) => {
        if (ech5[index]) {
            ech5[index].innerHTML = item; 
        }
    });

    data[currentLang].button.forEach((item, index) => {
        if (button[index]) {
            button[index].innerHTML = item; 
        }
    });

    data[currentLang].footer.forEach((item, index) => {
        if (footer[index]) {
            footer[index].innerHTML = item; 
        }
    });

    langBtn.innerHTML = currentLang === "ru" ? "en" : "ru"; // ru olsa en, en olsa ru olsun
};

langBtn.addEventListener('click', changeLang);

// let navLink = document.querySelectorAll('.nav-link');
// let langBtn = document.querySelector('#lang-btn');
// let paragraphh = document.getElementsByTagName('p');
// let ech1 = document.getElementsByTagName('h1');
// let ctitle = document.getElementsByClassName('card-title');
// let ctext = document.getElementsByClassName('card-text');
// let ech5 = document.getElementsByClassName('gr');
// let ech2 = document.getElementsByTagName('h2');
// let button = document.getElementsByClassName('btn');
// let footer = document.getElementsByTagName('p'); // Fixed the typo here

// const data = {
//     en: {
//         lang: ["Home", "Pages", "Projects", "Blog", "Blocks", "Documentation"],

//         ctitle: ["We are a creative company that focuses on long term relationships with customers.", "Content Marketing", "Social Engagement", "Card 3", "Product Design", "Collect Ideas", "Data Analysis", "Finalize Product", "Finalize Product"],

//         ctext: ["We are a creative company that focuses on long term relationships with customers."],

//         paragraphh: ["Why Choose Sandbox?", "Save Time and Money", "Financial Analyst", "Marketing Specialist", "Sales Manager", "WHAT MAKES US DIFFERENT?", "JOIN OUR COMMUNITY"],

//         ech2: ["Here are a few reasons why our customers choose Sandbox.", "Save your time and money by choosing our professional team.", "We are trusted by over 5000+ clients. Join them now and grow your business."],

//         ech1: ["We bring solutions to make life easier for our customers."],

//         ech5: ["Creativity","Innovative Thinking", "Rapid Solutions", "Top-Notch Support"],

//         footer: ["© 2024 MyWebsite", "All Rights Reserved", "info@mywebsite.com", "Get in Touch", "Moonshine St. 14/05", "London", "United Kingdom", "info@email.com", "00 (123) 456 78 90", "Learn More", "About Us", "Our Story", "Projects", "Terms of Use", "Privacy Policy", "Our Newsletter", "Subscribe to our newsletter to get our news & deals delivered to you."],

//         button: ["en", "read more", "Learn More", "Learn More", "Learn More", "Learn More", "Learn More", "Get started", "Previous", "Next", "Get Started", "Join"]
//     },
//     ru: {
//         lang: ["Главная страница", "Страницы", "Проекты", "Блог", "Блоки", "Документация"],

//         ctitle: ["Мы креативная компания, которая фокусируется на долгосрочных отношениях с клиентами", "Контент-маркетинг", "Социальное взаимодействие", "Карточка 3", "Дизайн продукта", "Сбор идей", "Анализ данных", "Финализация продукта", "Финализация продукта"],

//         ctext: ["Мы креативная компания, которая фокусируется на долгосрочных отношениях с клиентами."],

//         paragraphh: ["Почему стоит выбрать Sandbox?", "Экономьте время и деньги", "Финансовый аналитик", "Специалист по маркетингу", "Менеджер по продажам", "ЧЕМ МЫ ОТЛИЧАЕМСЯ?", "ПРИСОЕДИНЯЙТЕСЬ К НАШЕМУ СООБЩЕСТВУ"],

//         ech2: ["Вот несколько причин, по которым наши клиенты выбирают Sandbox", "Экономьте свое время и деньги, выбрав нашу профессиональную команду", "Нам доверяют более 5000+ клиентов. Присоединяйтесь к ним сейчас и развивайте свой бизнес."],

//         ech1: ["Мы предлагаем решения, которые облегчают жизнь нашим клиентам."],

//         ech5: ["Творчество","Инновационное мышление", "Быстрые решения", "Первоклассная поддержка"],

//         footer: ["© 2024 MyWebsite", "Все права защищены", "info@mywebsite.com", "Связаться", "Moonshine St. 14/05", "Лондон", "Соединенное Королевство", "info@email.com", "00 (123) 456 78 90", "Узнать больше", "О нас", "Наша история", "Проекты", "Условия использования", "Политика конфиденциальности", "Наша рассылка", "Подпишитесь на нашу рассылку, чтобы получать наши новости и предложения."],

//         button: ["ru", "читать дальше", "Узнать больше", "Узнать больше", "Узнать больше", "Узнать больше", "Узнать больше", "Начать", "Предыдущий", "Следующий", "Начать", "Присоединиться"]
//     }
// };

// const changeLang = () => {
//     // Determine current language and toggle to the other language
//     let currentLang = langBtn.innerHTML === "en" ? "ru" : "en";

//     // Update navigation links
//     data[currentLang].lang.forEach((item, index) => {
//         if (navLink[index]) {
//             navLink[index].innerHTML = item;
//         }
//     });

//     // Update card titles
//     data[currentLang].ctitle.forEach((item, index) => {
//         if (ctitle[index]) {
//             ctitle[index].innerHTML = item;
//         }
//     });

//     // Update card texts
//     data[currentLang].ctext.forEach((item, index) => {
//         if (ctext[index]) {
//             ctext[index].innerHTML = item;
//         }
//     });

//     // Update paragraphs
//     data[currentLang].paragraphh.forEach((item, index) => {
//         if (paragraphh[index]) {
//             paragraphh[index].innerHTML = item;
//         }
//     });

//     // Update h2 titles
//     data[currentLang].ech2.forEach((item, index) => {
//         if (ech2[index]) {
//             ech2[index].innerHTML = item;
//         }
//     });

//     // Update h1 titles
//     data[currentLang].ech1.forEach((item, index) => {
//         if (ech1[index]) {
//             ech1[index].innerHTML = item;
//         }
//     });

//     // Update ech5 (h5) titles
//     data[currentLang].ech5.forEach((item, index) => {
//         if (ech5[index]) {
//             ech5[index].innerHTML = item;
//         }
//     });

//     // Update buttons
//     data[currentLang].button.forEach((item, index) => {
//         if (button[index]) {
//             button[index].innerHTML = item;
//         }
//     });

//     // Update footer content
//     data[currentLang].footer.forEach((item, index) => {
//         if (footer[index]) {
//             footer[index].innerHTML = item;
//         }
//     });

//     // Toggle language button text
//     langBtn.innerHTML = currentLang === "ru" ? "en" : "ru";
// };

// // Attach the event handler to the language button
// langBtn.addEventListener('click', changeLang);

